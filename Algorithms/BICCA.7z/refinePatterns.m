function pattern = refinePatterns(pattern, dim)
P = numel(pattern);
reduce_index = zeros(1, P);
for i = 1: P
    if isempty(pattern(i).member)
        reduce_index(i) = 1;
    end
end
pattern(reduce_index == 1) = [];
M = sort(cat(2, pattern.member), 'ascend');
if ~isequal(1: dim, M)
    error('variable error');
end