function Sample_Curve = generateCurves(curves)
    global track;
    yyaxis left;
    points = 51;
    Sample_Curve = [];
    [points_num, ~] = size(track.evolution_curve);
    i = 1;
    for j = 0: points
        Sample_point = j * track.critical_values(3).evaluation / (points - 1);
        if Sample_point > track.critical_values(3).evaluation || j >= points
            break;
        end
        while track.evolution_curve(i, 1) < Sample_point && i < points_num
            i = i + 1;
        end
        Sample_Curve = [Sample_Curve; [Sample_point, track.evolution_curve(i, 2)]];
    end
    while Sample_point < track.critical_values(3).evaluation
        Sample_point = j * track.critical_values(3).evaluation / (points - 1);
        Sample_Curve = [Sample_Curve; [Sample_point, 0]];
        j = j + 1;
    end
    if strcmp(track.benchmark_version, 'CEC2008') && track.function_index == 7
        axis([0 track.critical_values(3).evaluation -inf 0]);
        plot(Sample_Curve(:, 1), Sample_Curve(:, 2), '-x');
    else
        axis([0 track.critical_values(3).evaluation 0 inf]);
        semilogy(Sample_Curve(:, 1), Sample_Curve(:, 2), '-x');
    end
    if strcmp(curves, 'both')
        yyaxis right;
        plot(track.activeness_curve(:, 1), track.activeness_curve(:, 2));
        axis([0 track.critical_values(3).evaluation 0 1]);
    end
	%str = sprintf('\n%d(+%d) %.2e %dmin %s', track.evolution_curve(end, 1), track.evals_saved, track.opt_fitness, track.time_log.duration);
    title([track.benchmark_version, ' f', num2str(track.function_index)]);
    legend('EC', 'AC');
    drawnow;
end