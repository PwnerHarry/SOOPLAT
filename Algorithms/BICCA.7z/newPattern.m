function pattern = newPattern(birth, death, member, success, fail, activeness, compactness)
    persistent pattern_number;
    if isempty(pattern_number)
        pattern_number = 1;
    else
        pattern_number = pattern_number + 1;
    end
    pattern.birth = birth;
    pattern.death = death;
    pattern.number = pattern_number;
    pattern.member = member;
    pattern.success = success;
    pattern.fail = fail;
    pattern.activeness = activeness;
    pattern.compactness = compactness;
end

