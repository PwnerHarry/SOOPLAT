classdef URM < handle
    properties
        matrix
    end
    methods
        function obj = URM(dimension)
            obj.matrix = zeros(dimension, dimension);
        end
        function obj = reinforce(obj, dims, success, fail)
            PLUS = zeros(size(obj.matrix));
            PLUS(dims, :) = PLUS(dims, :) + 1;
            PLUS(:, dims) = PLUS(:, dims) + 1;
            PLUS = (PLUS == 2);
            PLUS(logical(eye(size(PLUS)))) = 0;
            obj.matrix = obj.matrix + fail * tril(PLUS) + success * triu(PLUS);%the upper matrix is the successes, lower matrix is the fails
        end
    end
end

