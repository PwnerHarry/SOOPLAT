function syncOptimize(Generations, kernel, NP, Global)
    optimizePattern([], Generations, kernel, NP, Global);
end