function pattern = alterPatterns(pattern, delta, kernel, NP, U, group_size, Global)
pattern = detectPatterns(pattern, delta, kernel, NP, U, Global);
pattern = evolvePatterns(pattern, group_size, Global);
end