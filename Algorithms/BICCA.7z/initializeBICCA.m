function [pattern, group_size, delta, NP, kernel, interaction_cycles] = initializeBICCA(Global)
	global Current_Generations Mean_Generations Generation_Factor activeness_history;
    clear mark;
    clear newPattern;
    clear optimizePattern;
    % Other stuff
    delta.max = 0.4;
    delta.current = delta.max;
    delta.min = 0;
    delta.shape = 'linear';
    activeness_history = [0, 1];
    % Load Parameters
%     load('Parameters.mat');
%     if strcmp(func2str(Global.suite), 'CEC2008_LSO')
%         index = Global.func;
%     elseif strcmp(func2str(Global.suite), 'CEC2010_LSO')
%         index = Global.func + 7;
%     elseif strcmp(func2str(Global.suite), 'CEC2013_LSO')
%         index = Global.func + 7 + 20;
%     end
%     interaction_cycles = Parameters(index).interaction_cycles;
%     Generation_Factor = Parameters(index).Generation_Factor;
%     group_size = Parameters(index).group_size;
%     Mean_Generations = Parameters(index).Mean_Generations;
%     NP = Parameters(index).NP;
    interaction_cycles = 3;
    Generation_Factor = 1;
    group_size = 50;
    Mean_Generations = 500;
    NP = 15;
    kernel = 'LSHADE';
    pattern = initializePatterns([], group_size, Global);
    optimizePattern([], Mean_Generations, kernel, NP, Global);
    Current_Generations = Mean_Generations;
end