function Current_Generations = adjustGenerations(FEs_counter, maxFEs)
	Current_Generations = 100 + ceil(400 * FEs_counter / maxFEs);
end