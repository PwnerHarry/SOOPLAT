clear all;
for i = 1: 7
    load(['..\Arguments\CEC2008\Standard\', num2str(i), '.mat']);
    Parameters(i).benchmark_version = 'CEC2008';
    Parameters(i).function_index = i;
    if exist('eps', 'var')
        Parameters(i).eps = eps;
    else
        Parameters(i).eps = 0;
    end
    if exist('kernel', 'var')
        Parameters(i).kernel = kernel;
    else
        Parameters(i).kernel = 'ACoDE';
    end
    if exist('interaction_cycles', 'var')
        Parameters(i).interaction_cycles = interaction_cycles;
    else
        Parameters(i).interaction_cycles = 2;
    end
    if exist('Generation_Factor', 'var')
        Parameters(i).Generation_Factor = Generation_Factor;
    else
        Parameters(i).Generation_Factor = 1;
    end
    if exist('group_size', 'var')
        Parameters(i).group_size = group_size;
    else
        Parameters(i).group_size = 50;
    end
    if exist('Mean_Generations', 'var')
        Parameters(i).Mean_Generations = Mean_Generations;
    else
        Parameters(i).Mean_Generations = 500;
    end
    if exist('NP', 'var')
        Parameters(i).NP = NP;
    else
        Parameters(i).NP = 15;
    end
    if exist('Xmin', 'var')
        Parameters(i).lower_bound = Xmin;
    else
        error('no Xmin?!');
    end
    if exist('Xmax', 'var')
        Parameters(i).upper_bound = Xmax;
    else
        error('no Xmax?!');
    end
    clear Xmin Xmax CF interaction_cycles kernel NP eps Mean_Generations group_size Generation_Factor;
end
for i = 1: 20
    load(['..\Arguments\CEC2010\Standard\', num2str(i), '.mat']);
    Parameters(i + 7).benchmark_version = 'CEC2010';
    Parameters(i + 7).function_index = i;
    if exist('eps', 'var')
        Parameters(i + 7).eps = eps;
    else
        Parameters(i + 7).eps = 0;
    end
    if exist('kernel', 'var')
        Parameters(i + 7).kernel = kernel;
    else
        Parameters(i + 7).kernel = 'ACoDE';
    end
    if exist('interaction_cycles', 'var')
        Parameters(i + 7).interaction_cycles = interaction_cycles;
    else
        Parameters(i + 7).interaction_cycles = 2;
    end
    if exist('Generation_Factor', 'var')
        Parameters(i + 7).Generation_Factor = Generation_Factor;
    else
        Parameters(i + 7).Generation_Factor = 1;
    end
    if exist('group_size', 'var')
        Parameters(i + 7).group_size = group_size;
    else
        Parameters(i + 7).group_size = 50;
    end
    if exist('Mean_Generations', 'var')
        Parameters(i + 7).Mean_Generations = Mean_Generations;
    else
        Parameters(i + 7).Mean_Generations = 500;
    end
    if exist('NP', 'var')
        Parameters(i + 7).NP = NP;
    else
        Parameters(i + 7).NP = 15;
    end
    if exist('Xmin', 'var')
        Parameters(i + 7).lower_bound = Xmin;
    else
        error('no Xmin?!');
    end
    if exist('Xmax', 'var')
        Parameters(i + 7).upper_bound = Xmax;
    else
        error('no Xmax?!');
    end
    clear Xmin Xmax CF interaction_cycles kernel NP eps Mean_Generations group_size Generation_Factor;
end
for i = 1: 15
    load(['..\Arguments\CEC2013\Standard\', num2str(i), '.mat']);
    Parameters(i + 7 + 20).benchmark_version = 'CEC2013';
    Parameters(i + 7 + 20).function_index = i;
    if exist('eps', 'var')
        Parameters(i + 7 + 20).eps = eps;
    else
        Parameters(i + 7 + 20).eps = 0;
    end
    if exist('kernel', 'var')
        Parameters(i + 7 + 20).kernel = kernel;
    else
        Parameters(i + 7 + 20).kernel = 'ACoDE';
    end
    if exist('interaction_cycles', 'var')
        Parameters(i + 7 + 20).interaction_cycles = interaction_cycles;
    else
        Parameters(i + 7 + 20).interaction_cycles = 2;
    end
    if exist('Generation_Factor', 'var')
        Parameters(i + 7 + 20).Generation_Factor = Generation_Factor;
    else
        Parameters(i + 7 + 20).Generation_Factor = 1;
    end
    if exist('group_size', 'var')
        Parameters(i + 7 + 20).group_size = group_size;
    else
        Parameters(i + 7 + 20).group_size = 50;
    end
    if exist('Mean_Generations', 'var')
        Parameters(i + 7 + 20).Mean_Generations = Mean_Generations;
    else
        Parameters(i + 7 + 20).Mean_Generations = 500;
    end
    if exist('NP', 'var')
        Parameters(i + 7 + 20).NP = NP;
    else
        Parameters(i + 7 + 20).NP = 15;
    end
    if exist('Xmin', 'var')
        Parameters(i + 7 + 20).lower_bound = Xmin;
    else
        error('no Xmin?!');
    end
    if exist('Xmax', 'var')
        Parameters(i + 7 + 20).upper_bound = Xmax;
    else
        error('no Xmax?!');
    end
    clear Xmin Xmax CF interaction_cycles kernel NP eps Mean_Generations group_size Generation_Factor;
    save('../Parameters.mat', 'Parameters');
end
