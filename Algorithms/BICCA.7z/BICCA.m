function BICCA2(Global)
[pattern, group_size, delta, NP, kernel, ~] = initializeBICCA(Global);
cycles = 0;
while ~Global.terminated
    syncOptimize(Global.problem.dimension, kernel, NP, Global);
    [pattern, delta] = asyncOptimize(pattern, group_size, NP, delta, kernel, [], Global);
    pattern = alterPatterns(pattern, delta, kernel, NP, [], group_size, Global);
    cycles = cycles + 1;
end
fprintf('cycles: %d\n', cycles);