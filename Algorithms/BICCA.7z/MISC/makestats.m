function M = makestats(benchmark_version, function_index, points, dimension)
    hold off;
    fileFolder = fullfile(['..\Data\', benchmark_version, '\', num2str(function_index), '\']);
    dirOutput = dir(fullfile(fileFolder, '*'));
    filenames = {dirOutput.name}';
    filenames(1: 2) = [];
    [fnum, ~] = size(filenames);
    X = NaN(points, 25);
    M = zeros(points, 2);
    filenames = char(filenames);
    maxFEs = 0;
    if fnum > 0
        for i = 1: fnum
            load(['..\Data\', benchmark_version, '\', num2str(function_index), '\', filenames(i, :)]);
            if track.arguments.dimension ~= dimension
                continue;
            elseif maxFEs == 0
                maxFEs = track.critical_values(3).evaluation;
            end
            x = generateSamples(points);
            if i == 1
                M(:, 1) = x(:, 1);
            end
            x(:, 1) = [];
            X(:, i) = x;
        end
        critical_values = track.critical_values;
        for i = 1: points
            M(i, 2) = mean(X(i, :), 'omitnan');
            for j = 1: 3
                if M(i, 1) == track.critical_values(j).evaluation
                    critical_values(j).fitness = M(i, 2);
                end
            end
        end
        if strcmp(benchmark_version, 'CEC2008') && function_index == 7
            plot([0; M(:, 1)], [0; M(:, 2)], '-x');
            axis([0 maxFEs -inf 0]);
        else
            semilogy([0; M(:, 1)], [inf; M(:, 2)], '-x');
            axis([0 maxFEs 0 inf]);
        end
    %     str1 = [sprintf('%.2e', critical_values(1).evaluation), ', ', sprintf('%.2e', critical_values(1).fitness)];
    %     str2 = [sprintf('%.2e', critical_values(2).evaluation), ', ', sprintf('%.2e', critical_values(2).fitness)];
    %     str3 = [sprintf('%.2e', critical_values(3).evaluation), ', ', sprintf('%.2e', critical_values(3).fitness)];
    %     text(critical_values(1).evaluation, critical_values(1).fitness, ['\downarrow ', str1]);
    %     text(critical_values(2).evaluation, critical_values(2).fitness, ['\downarrow ', str2]);
    %     text(critical_values(3).evaluation, critical_values(3).fitness, ['\rightarrow ', str3]);
        legend([benchmark_version, ' - f', num2str(function_index)]);
        drawnow;
        saveas(gcf, ['..\Data\Overall\', benchmark_version, '-f', num2str(function_index), '.fig']);
        saveas(gcf, ['..\Data\Overall\', benchmark_version, '-f', num2str(function_index), '.eps'], 'psc2');
        save(['..\Data\Overall\', benchmark_version, '-f', num2str(function_index), '.mat'], 'M');
    end
end
function Sample_Curve = generateSamples(points)
    global track;
    Sample_Curve = [];
    [points_num, ~] = size(track.evolution_curve);
    i = 1;
    for j = 0: points
        Sample_point = j * track.critical_values(3).evaluation / (points - 1);
        if Sample_point > track.critical_values(3).evaluation || j >= points
            break;
        end
        while track.evolution_curve(i, 1) < Sample_point && i < points_num
            i = i + 1;
        end
        Sample_Curve = [Sample_Curve; [Sample_point, track.evolution_curve(i, 2)]];
    end
    while Sample_point < track.critical_values(3).evaluation
        Sample_point = j * track.critical_values(3).evaluation / (points - 1);
        Sample_Curve = [Sample_Curve; [Sample_point, 0]];
        j = j + 1;
    end
end