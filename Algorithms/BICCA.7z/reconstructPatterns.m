function pattern = reconstructPatterns(NP, group_size, R, Global)
    global flag;
    fprintf('Pattern Reconstruction\n');
    Pop = zeros(NP, Global.problem.dimension);
    block.member = [];
    block.size = 0;
    blocks = repmat(block, Global.problem.dimension, 1);
    if flag == 1
        acc = 0;
        pointer = 1;
        base_pattern_vector = zeros(1, Global.problem.dimension);
        for i = 1: Global.problem.dimension
            base_pattern_vector(i) = pointer;
            acc = acc + 1;
            if acc > group_size
                pointer = pointer + 1;
                acc = 0;
            end
        end
        for k = 1: NP
            pattern_vector = base_pattern_vector(randperm(Global.problem.dimension));
            Pop(k, :) = pattern_vector;
        end
    else
        for i = 1: Global.problem.dimension
            blocks(i).member = i;
            for j = 1: Global.problem.dimension
                if i == j
                    continue;
                end
                if R(i, j) == 0 && R(j, i) == 0
                    blocks(i).member = [blocks(i).member, j];
                end
            end
            blocks(i).member = sort(blocks(i).member, 'descend');
            blocks(i).size = numel(blocks(i).member);
        end
        %          [~, index] = sort([blocks.size], 'descend');
        %          blocks = blocks(index);
        %         for i = 1: numel(blocks)
        %             for j = i + 1: numel(blocks)
        %                 blocks(j).member = setdiff(blocks(j).member, blocks(i).member);
        %             end
        %             blocks(i).member = unique([blocks(i).member, i]);
        %             blocks(i).size = numel(blocks(i).member);
        %         end
        [~, index] = sort([blocks.size], 'ascend');
        blocks = blocks(index);
        while blocks(1).size == 0
            blocks(1) = [];
        end
        for k = 1: NP
            pattern_vector = zeros(1, Global.problem.dimension);
            strategy = 2;
            if strategy == 1
                combined_blocks = blocks;
            elseif strategy == 2
                combined_blocks = [];
                member = [];
                pointer = 1;
                for i = 1: numel(blocks)
                    member = [member, blocks(i).member];
                    if numel(member) > group_size
                        combined_blocks(pointer).member = member;
                        combined_blocks(pointer).size = numel(member);
                        pointer = pointer + 1;
                        member = [];
                    end
                end
            end
            combined_blocks = combined_blocks(randperm(numel(combined_blocks)));
            for i = 1: numel(combined_blocks)
                pattern_vector(combined_blocks(i).member) = i;
            end
            if ~isempty(find(pattern_vector == 0, 1))
                error('wtf');
            end
            Pop(k, :) = pattern_vector;
            if max([combined_blocks.size]) == 1
                flag = 1;
            end
        end
    end
    RR = R ./ (R + R');
    RR(isnan(RR)) = 0;
    fit = R_evaluation(Pop, max(max(Pop)), RR);
    [~, index] = min(fit);
    optvec = Pop(index, :);
    for i = 1: max(max(Pop))
        pattern(i) = newPattern(Global.evaluated, inf, find(optvec == i), 0, 0, 0, 0);
    end
    pattern = refinePatterns(pattern, Global.problem.dimension);
end

function fit = R_evaluation(pop, group, r)
    [height, ~] = size(pop);
    fit = zeros(1, height);
    for h = 1: height
        V = pop(h, :);
        S = 0;
        edges = 0;
        for g = 1: group
            index = find(V == g);
            if numel(index) > 1
                sum = 0;
                for i = 1: numel(index)
                    for j = i + 1: numel(index)
                        sum = sum - r(index(i), index(j));
                    end
                end
                e = nchoosek(numel(index), 2);
                edges = edges + e;
                S = S + sum;
            end
        end
        fit(h) = S / edges;
    end
end