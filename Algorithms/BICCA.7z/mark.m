function R = mark(R, member, success, fail, Global)
    persistent empty_slots;
    if isempty(empty_slots)
        empty_slots = numel(find((R + R') == 0));
    end
    PLUS = zeros(size(R));
    PLUS(member, :) = PLUS(member, :) + 1;
    PLUS(:, member) = PLUS(:, member) + 1;
    PLUS = (PLUS == 2);
    PLUS(logical(eye(size(PLUS)))) = 0;
    R = R + fail * tril(PLUS) + success * triu(PLUS);%the upper matrix is the successes, lower matrix is the fails
    new_empty_slots = numel(find((R + R') == 0));
    E = empty_slots - new_empty_slots;
    empty_slots = new_empty_slots;
    if E > 0
        fprintf('eliminated %d empty slots, %.2f%% remaining\n', E, 100 * empty_slots / (Global.problem.dimension * Global.problem.dimension));
    elseif E < 0
        error('wtf');
    end
end
