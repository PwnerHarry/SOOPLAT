function [pattern, delta] = asyncOptimize(pattern, group_size, NP, delta, kernel, U, Global)
    global activeness_history Current_Generations;
	fprintf('Asynchronous Optimization\n');
	activeness_vector = zeros(1, numel(pattern));
    mean_activeness = 0;
	for i = randperm(numel(pattern))
        [pattern(i).success, pattern(i).fail] = optimizePattern(pattern(i).member, ceil(Current_Generations * numel(pattern(i).member) / group_size), kernel, NP, Global);
        %[pattern(i).success, pattern(i).fail] = feval(str2func(kernel), ceil(Current_Generations * numel(pattern(i).member) / group_size), NP, pattern(i).member, Global);
        pattern(i).activeness = pattern(i).success ./ (pattern(i).success + pattern(i).fail);
        fprintf('Pa%d:\t%d%%\n', pattern(i).number, round(100 * pattern(i).activeness));
        % U.reinforce(pattern(i).member, pattern(i).success, pattern(i).fail);
        activeness_vector(i) = pattern(i).activeness;
        mean_activeness = mean_activeness + pattern(i).activeness * numel(pattern(i).member) / Global.problem.dimension;
    end
    activeness_vector = sort(activeness_vector, 'descend');
    delta.current = median(activeness_vector);
	fprintf('mean_activeness: %d%%\n', fix(100 * mean_activeness));
	activeness_history = [activeness_history; [Global.evaluated, mean_activeness]]; 
end