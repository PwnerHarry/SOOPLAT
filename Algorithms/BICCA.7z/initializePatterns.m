function new_pattern = initializePatterns(~, group_size, Global)
    fprintf('initlializePatterns\n');
    group_number = ceil(Global.problem.dimension / group_size);
    group = randi(group_number, 1, Global.problem.dimension);
    for i = 1: group_number
        new_pattern(i) = newPattern(Global.evaluated, inf, find(group == i), 0, 0, 0, 0);
    end
end