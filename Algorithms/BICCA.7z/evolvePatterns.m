function pattern = evolvePatterns(pattern, group_size, Global)
    fprintf('Pattern Evolution\n');
    max_activeness = 0;
    for i = 1: numel(pattern)
        max_activeness = max(pattern(i).activeness, max_activeness);
    end
    C = zeros(1, numel(pattern));
    for i = 1: numel(pattern)
        if numel(pattern(i).member) > 1 %A pattern not scatter
            choice = evolution(pattern(i), max_activeness);
            if strcmp(choice, 'merge')%C_i = 1
                C(i) = 1; %merge with another pattern
            elseif strcmp(choice, 'expand')%C_i = 2
                C(i) = 2; %merge with a scattered pattern
            end
        elseif numel(pattern(i).member) == 1 %For the scatters? %C_i = 3
            C(i) = 3;
        end
    end
    p_merge = find(C == 1);
    p_expand = find(C == 2);
    p_cluster = find(C == 3);
    %pattern merge
    p_merge_size = zeros(1, numel(p_merge));
    p_merge_temp = [];
    for i = 1: numel(p_merge)
        p_merge_size(i) = numel(pattern(p_merge(i)).member);
    end
    while numel(p_merge) > 0
        [~, index] = max(p_merge_size);
        p_merge_temp = [p_merge_temp, p_merge(index)];
        p_merge(index) = [];
        p_merge_size(index) = [];
    end
    p_merge = p_merge_temp;
    while numel(p_merge) > 1
        r1 = randi(numel(p_merge));
        r2 = randi(numel(p_merge));
        while r1 == r2
            r1 = randi(numel(p_merge));
            r2 = randi(numel(p_merge));
        end
        if numel(pattern(p_merge(r1)).member) + pattern(p_merge(r2)).member < group_size
            pattern(p_merge(r1)).death = Global.evaluated;
            pattern(p_merge(r2)).death = Global.evaluated;
            pattern_size = numel(pattern);
            pattern(pattern_size + 1) = newPattern(Global.evaluated, inf, [pattern(p_merge(r1)).member, pattern(p_merge(r2)).member], 0, 0, 0, 0);
            pattern(p_merge(r1)).member = [];
            pattern(p_merge(r2)).member = [];
            p_merge([r1, r2]) = [];
        else
            p_merge(r1) = [];
        end
    end
    %pattern expand: collect scatters
    p_cluster = p_cluster(randperm(numel(p_cluster)));% shuffle p_cluster
    for i = p_expand
        if isempty(p_cluster)
            break;
        end
        r = randi(max(1, group_size - 1 - numel(pattern(i).member))) + 1;
        for j = 1: r
            if isempty(p_cluster)
                break;
            end
            pattern(i).member = [pattern(i).member pattern(p_cluster(1)).member];
            pattern(p_cluster(1)).member = [];
            p_cluster(1) = [];
        end
        pattern(i).success = 0;
        pattern(i).fail = 0;
        pattern(i).activeness = 0;
        pattern(i).compactness = 0;
    end
    %scattered points cluster: scattered points cluster into some patterns
    if numel(p_cluster) > 1
        %p_cluster already shuffled
        r = randi(group_size - 1) + 1;
        while r < numel(p_cluster)
            fuse = p_cluster(1: r);
            p_cluster = p_cluster(r + 1: end);
            D = cat(2, pattern(fuse).member);
            for i = fuse
                pattern(i).member = [];
            end
            pattern_size = numel(pattern);
            pattern(pattern_size + 1) = newPattern(Global.evaluated, inf, D, 0, 0, 0, 0);
            %combine r scattered points together and remove these points
            %from p_cluster
            r = randi(group_size - 1) + 1;
        end
        %combine u scattered points together
        D = cat(2, pattern(p_cluster).member);
        for i = p_cluster
            pattern(i).member = [];
        end
        pattern_size = numel(pattern);
        pattern(pattern_size + 1) = newPattern(Global.evaluated, inf, D, 0, 0, 0, 0);
    end
    pattern = refinePatterns(pattern, Global.problem.dimension);
end
function choice = evolution(pattern, max_activeness)
    gamma = 0.6;
    mu = 0.3;
    p_remain = gamma * pattern.compactness + (1 - gamma) * pattern.activeness / max_activeness;%standardize!
    p_merge = mu * (1 - p_remain);
    pointer = rand();
    if pointer < p_merge
        choice = 'merge';
    elseif pointer > 1 - p_remain - p_merge
        choice = 'expand';
    else
        choice = 'remain';
    end
end
