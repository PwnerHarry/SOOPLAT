function [success, fail] = optimizePattern(dims, maxGen, kernel, NP, Global)
    persistent contextPopulation ccm;
    mode = 1;
    if mode == 1
        if strcmp(kernel, 'LSHADE')
            [success, fail, ~] = LSHADE('-initPop', Global.bestIndividual, '-maxGen', maxGen, '-meanNP', NP, '-dims', dims, '-Global', Global);
            %[success, fail, ~] = LSHADE('-initPop', contextPopulation, '-maxGen', maxGen, '-NP', NP, '-dims', dims, '-Global', Global);
        else
            [success, fail, ~] = feval(kernel, '-initPop', Global.bestIndividual, '-maxGen', maxGen, '-NP', NP, '-dims', dims, '-Global', Global);
        end
    elseif mode == 2
        if isempty(contextPopulation)
            contextPopulation = repmat(Global.problem.lowerbound, NP, 1) + rand(NP, Global.problem.dimension) .* repmat(Global.problem.upperbound - Global.problem.lowerbound, NP, 1);
        end
        initPop = contextPopulation;
        randPointer = randi(size(contextPopulation, 1));
        badassVector = contextPopulation(randPointer, :);
        initPop(randPointer, :) = Global.bestIndividual;
        if strcmp(kernel, 'LSHADE')
            [success, fail, precontextPopulation] = LSHADE('-initPop', initPop, '-maxGen', maxGen, '-meanNP', NP, '-dims', dims, '-Global', Global);
            %[success, fail, precontextPopulation] = LSHADE('-initPop', contextPopulation, '-maxGen', maxGen, '-NP', NP, '-dims', dims, '-Global', Global);
        else
            [success, fail, precontextPopulation] = feval(kernel, '-initPop', initPop, '-maxGen', maxGen, '-NP', NP, '-dims', dims, '-Global', Global);
        end
        chosenOnes = randperm(NP);
        chosenOnes = chosenOnes(1: min(size(precontextPopulation, 1), NP));
        if isempty(dims)
            contextPopulation(chosenOnes, :) = precontextPopulation(1: min(size(precontextPopulation, 1), NP), :);
        else
            contextPopulation(chosenOnes, dims) = precontextPopulation(1: min(size(precontextPopulation, 1), NP), dims);
        end
        contextPopulation(randPointer, :) = badassVector;
    elseif mode == 3
        if isempty(contextPopulation)
            contextPopulation = repmat(Global.problem.lowerbound, NP, 1) + rand(NP, Global.problem.dimension) .* repmat(Global.problem.upperbound - Global.problem.lowerbound, NP, 1);
            ccm = 0.5;
        end
        [precontextPopulation, ~, ccm, success, fail] = SaNSDE('-crossRate', ccm, '-NP', NP, '-dims', dims, '-initPop', contextPopulation, '-contextVector', Global.bestIndividual, '-contextFitness', Global.bestFitness, '-maxGen', maxGen, '-Global', Global);
        contextPopulation(:, dims) = precontextPopulation(:, dims);
    end
	Global.draw();
end