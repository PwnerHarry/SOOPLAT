function pattern = detectPatterns(pattern, delta, kernel, NP, U, Global)
    fprintf('Pattern Detection\n');
    [~, index] = sort([pattern.activeness], 'descend');
    for i = index
        if pattern(i).activeness < delta.current %if a group has an activeness < delta then break it!
            pattern(i).death = Global.evaluated;
            member = pattern(i).member;
            pattern(i).member = [];
            while ~isempty(member)
                pattern_size = numel(pattern);
                pattern(pattern_size + 1) = newPattern(Global.evaluated, inf, member(1), 0, 0, 0, 0);
                member(1) = [];
            end
        elseif numel(pattern(i).member) >= 4
			fprintf('P%d:\t', pattern(i).number);
			pre_patterns = SliceTest(pattern(i), 5, kernel, NP, U, Global);
            if numel(pre_patterns) == 1
                used_member = pre_patterns.member;
                pattern_size = numel(pattern);
                pattern(pattern_size + 1) = pre_patterns;
            elseif numel(pre_patterns) == 2
                used_member = [pre_patterns(1).member, pre_patterns(2).member];
                pattern_size = numel(pattern);
                pattern(pattern_size + 1) = pre_patterns(1);
                pattern(pattern_size + 2) = pre_patterns(2);
            end
            unused_member = setdiff(pattern(i).member, used_member);
            fprintf('cut into %d patterns by reducing %d scatters\n', numel(pre_patterns), numel(unused_member));
            while ~isempty(unused_member)
                pattern_size = numel(pattern);
                pattern(pattern_size + 1) = newPattern(Global.evaluated, inf, unused_member(1), 0, 0, 0, 0);
                unused_member(1) = [];
            end
            pattern(i).member = [];
        end
    end
    pattern = refinePatterns(pattern, Global.problem.dimension);
end

function pre_patterns = SliceTest(pattern, generations, kernel, NP, U, Global)
    pre_patterns = [];
    member = pattern.member;
    member = member(randperm(numel(member)));
    slice_position = randi(numel(member) - 3) + 1;
    sub_a = member(1: slice_position);
    sub_b = member(slice_position + 1: end);
    %[success, fail] = optimizePattern(dims, maxGen, kernel, NP, Global)
    [sub_a_success, sub_a_fail] = optimizePattern(sub_a, generations, kernel, NP, Global);
    [sub_b_success, sub_b_fail] = optimizePattern(sub_b, generations, kernel, NP, Global);
    % U.reinforce(sub_a, sub_a_success, sub_a_fail);
    % U.reinforce(sub_b, sub_b_success, sub_b_fail);
    if sub_a_success == 0 && sub_b_success > 0
        [sub_a, sub_b] = swap(sub_a, sub_b);
        [sub_a_success, sub_b_success] = swap(sub_a_success, sub_b_success);
        [sub_a_fail, sub_b_fail] = swap(sub_a_fail, sub_b_fail);
    end
    while sub_a_success > 0 && sub_b_success == 0
        if numel(sub_a) < 4
            pre_patterns = newPattern(Global.evaluated, inf, sub_a, sub_a_success, sub_a_fail, sub_a_success / (sub_a_success + sub_a_fail), 1);
            return;
        end
        %keep slicing a
        member = sub_a;
        member = member(randperm(numel(member)));
        slice_position = randi(numel(member) - 3) + 1;
        sub_a = member(1: slice_position);
        sub_b = member(slice_position + 1: end);
        [sub_a_success, sub_a_fail] = optimizePattern(sub_a, generations, kernel, NP, Global);
        [sub_b_success, sub_b_fail] = optimizePattern(sub_b, generations, kernel, NP, Global);
        % U.reinforce(sub_a, sub_a_success, sub_a_fail);
        % U.reinforce(sub_b, sub_b_success, sub_b_fail);
        if sub_a_success == 0 && sub_b_success > 0
            [sub_a, sub_b] = swap(sub_a, sub_b);
            [sub_a_success, sub_b_success] = swap(sub_a_success, sub_b_success);
            [sub_a_fail, sub_b_fail] = swap(sub_a_fail, sub_b_fail);
        end
    end
    if sub_a_success == 0 && sub_b_success == 0
        pre_patterns = newPattern(Global.evaluated, inf, [sub_a, sub_b], 0, 0, 0, 0);
        pre_patterns.compactness = 1; %Compactness set to 1
        return;
    elseif sub_a_success > 0 && sub_b_success > 0
        p1 = sub_a_success / (sub_a_success + sub_b_success);
        p2 = sub_b_success / (sub_a_success + sub_b_success);
        sub_a_compactness = 1 - p1 * log2(p1) / (p1 * log2(p1) + p2 * log2(p2));
        sub_b_compactness = 1 - p2 * log2(p2) / (p1 * log2(p1) + p2 * log2(p2));
        pre_patterns = newPattern(Global.evaluated, inf, sub_a, sub_a_success, sub_a_fail, sub_a_success / (sub_a_success + sub_a_fail), sub_a_compactness);
        pre_patterns(2) = newPattern(Global.evaluated, inf, sub_b, sub_b_success, sub_b_fail, sub_b_success / (sub_b_success + sub_b_fail), sub_b_compactness);
        return;
    end
end
function [c, d] = swap(a, b)
    c = b;
    d = a;
end